# ==============================================================================
# MANCALA
# ==============================================================================
"""MANCALA : le jeu du Mancala avec options de jeu"""
__author__  = "Tallulah Gilliard"
__version__ = "1.0"
__date__    = "2014-11-08"
__usage__   = """
Parametres optionnels : [c=valeur] [g=valeur] [r=kalah, awele ou oware]
        avec
        c = nombre de cases (1 à 9)
        g = nombre de graines (1 à 9)
        r = regle du jeu parmi (kalah, awele ou oware)
Parametres par defaut : c=6 g=4 r=kalah
Note : taper ENTREE seul pour jouer avec les parametres par defaut"""
# ==============================================================================

import pygame, sys
from pygame.locals import *

class Silo:
	def __init__(self):
		self.graines = 0

class Case:
	def __init__(self, nombreGraines):
		self.graines = nombreGraines

class Plateau:
	def __init__(self, nombreCases, nombreGraines, regle):
		self.Silos = [Silo(), Silo()]
		self.Cases = []
		liste1 = []
		liste2 = []
		self.Cases.append(liste1)
		self.Cases.append(liste2)
		for each in range(nombreCases): liste1.append(Case(nombreGraines)) 
		for each in range(nombreCases): liste2.append(Case(nombreGraines)) 
		self.numeroJoueur = 0;
		self.nombreCases = nombreCases 
		self.nombreGrainesTotal = nombreGraines * nombreCases*2 
		self.regle = regle
		self.finDuJeu = False

	
	def tourDeJeu(self, NumeroCase):
		caseActive = self.Cases[self.numeroJoueur][NumeroCase]
		contexte = SauveContexte(self.numeroJoueur, NumeroCase, caseActive.graines)
		caseActive.graines = 0

		numeroDeCase = NumeroCase
		while contexte.nombreDeGraineDansLaMain > 0: # deplacement tant qu il y a des graines dans la main
			self.__deplacement(contexte)

		if contexte.finDuTourDansSilo == False: # fin du tour dans une case, pas dans un silo
			if self.regle == 'awele':
				if self.Cases[contexte.numeroCoteDuPlateau][contexte.numeroDeCase].graines == 1:   # c etait une case vide
					self.__captureCasesOpposees(contexte.numeroCoteDuPlateau, contexte.numeroDeCase)                        
			elif self.regle == 'kalah':
				if self.Cases[contexte.numeroCoteDuPlateau][contexte.numeroDeCase].graines == 1:   # c etait une case vide
					if contexte.numeroCoteDuPlateau == self.numeroJoueur:
						self.__captureCasesOpposees(contexte.numeroCoteDuPlateau, contexte.numeroDeCase)
			elif self.regle == 'oware':
				if self.Cases[contexte.numeroCoteDuPlateau][contexte.numeroDeCase].graines in {2, 3}:
					if contexte.numeroCoteDuPlateau != self.numeroJoueur: # camp adverse
						self.Silos[self.numeroJoueur].graines += self.Cases[contexte.numeroCoteDuPlateau][contexte.numeroDeCase].graines
						self.Cases[contexte.numeroCoteDuPlateau][contexte.numeroDeCase].graines = 0

						case = contexte.numeroDeCase - 1 #on prend les voisins des cases de gauche si 1 ou 2 graines
						while case >= 0 and self.Cases[contexte.numeroCoteDuPlateau][case].graines in {2, 3}:
							self.Silos[self.numeroJoueur].graines += self.Cases[contexte.numeroCoteDuPlateau][case].graines
							self.Cases[contexte.numeroCoteDuPlateau][case].graines = 0
							case -= 1

						case = contexte.numeroDeCase + 1 #on prend les voisins des cases de droite si 1 ou 2 graines
						while case < self.nombreCases and self.Cases[contexte.numeroCoteDuPlateau][case].graines in {2, 3}:
							self.Silos[self.numeroJoueur].graines += self.Cases[contexte.numeroCoteDuPlateau][case].graines
							self.Cases[contexte.numeroCoteDuPlateau][case].graines = 0
							case += 1

			if self.Silos[self.numeroJoueur].graines > self.nombreGrainesTotal/2: # fin du jeu si moitie des graines recoltees
				self.finDuJeu = True

			if self.__plusDeDeplacementPossible():
				self.finDuJeu = True 

			self.numeroJoueur = (self.numeroJoueur + 1) % 2 # joueur suivant que si fin dans case et non dans silo


	def __deplacement(self, contexte):
		contexte.numeroDeCase = (contexte.numeroDeCase + 1) % (self.nombreCases+1) # case (0-self.nombreCases-1) suivante ou silo  
		if contexte.numeroDeCase == self.nombreCases: #silo  
			if contexte.numeroCoteDuPlateau == self.numeroJoueur: #le silo du joueur qui joue
				self.Silos[contexte.numeroCoteDuPlateau].graines += 1
				contexte.nombreDeGraineDansLaMain -= 1
				contexte.finDuTourDansSilo = True
			contexte.numeroCoteDuPlateau = (contexte.numeroCoteDuPlateau + 1) % 2
		else: #case
			self.Cases[contexte.numeroCoteDuPlateau][contexte.numeroDeCase].graines += 1
			contexte.nombreDeGraineDansLaMain -= 1
			contexte.finDuTourDansSilo = False

	def __captureCasesOpposees(self, numeroDuJoueur, numeroDeCase):
		print ("__captureCasesOpposees")
		caseOpposee = self.Cases[(numeroDuJoueur + 1) % 2][(self.nombreCases-1) - numeroDeCase]  # case
		if caseOpposee.graines > 0:
			caseJoueur = self.Cases[numeroDuJoueur][numeroDeCase]
			self.Silos[self.numeroJoueur].graines += caseJoueur.graines + caseOpposee.graines  # avec caseJoueur.graines = 1
			caseOpposee.graines,caseJoueur.graines = 0,0

	def __plusDeDeplacementPossible(self):
		for Case in self.Cases[self.numeroJoueur]:
			if Case.graines > 0: # il reste des graines
				return False
		return True # il ne reste plus de graines

class SauveContexte:
	def __init__(self, numeroDuJoueur, numeroDeCase, nombreDeGraineDansLaCase):
		self.numeroCoteDuPlateau = numeroDuJoueur
		self.numeroDeCase = numeroDeCase
		self.nombreDeGraineDansLaMain = nombreDeGraineDansLaCase
		self.finDuTourDansSilo = False


def setoptions(options, command):
	"""retourne un dictionnaire d'options mises a jour par command"""
	for option in command:
		option = option.split('=')
		try:
			if len(option) != 2 \
			or option[1] == '' \
			or option[0] not in options \
			or (option[0] in {'c', 'g'} and int(option[1]) not in range(1,10)) \
			or (option[0] is 'r' and option[1] not in {'oware', 'kalah', 'awele'}):
				print("\nErreur de saisie des parametres.\nLes options erronees sont ignorees.\n %s\n" % (__usage__))
			else:
				options[option[0]] = option[1]
		except: #saisie d'entier a la place de chaines ou inversement (ex: c='kalah')
			print("\nErreur de saisie des parametres.\nLes options erronees sont ignorees.\n %s\n" % (__usage__))
	return options


def main():
	DEBUG = False
	origineX = 50
	origineY = 50
	largeurCase = 61
	hauteurCase = 72
	tailleFenetreX = 800
	tailleFenetreY = 300
        
	print("%s\n%s%s\n%s" % ('='*80, __doc__, __usage__, '='*80))

	options = {'c':'6', 'g':'4', 'r':'kalah'}
	if DEBUG:
		print (options) 
	ligneOptions = input("<> Entrez vos parametres : ") # on met a jour les options a partir du tableau genere par split
	options = setoptions(options, ligneOptions.split())
	print ('Demarrage du jeu avec les parametres : ',options)     

	# Affichage--------------------------------------------
	pygame.init()
	myfont = pygame.font.SysFont("monospace", 20)
	myfont.set_bold(True)
	fenetre = pygame.display.set_mode((tailleFenetreX, tailleFenetreY))
	pygame.display.set_caption("Mancala")
	fond = pygame.image.load("fond.jpg").convert()
	fenetre.blit(fond, (0,0))

	imageSiloVide = pygame.image.load("silo.jpg").convert()
	imageSilo1 = pygame.image.load("silo1.jpg").convert()
	imageSilo2 = pygame.image.load("silo2.jpg").convert()
	imageSilo3 = pygame.image.load("silo3.jpg").convert()
	imageSilo4 = pygame.image.load("silo4.jpg").convert()
	imageSilo5 = pygame.image.load("silo5.jpg").convert()
	imageSilo6 = pygame.image.load("silo6.jpg").convert()
	imageSilo7 = pygame.image.load("silo7.jpg").convert()
	imageSilo8 = pygame.image.load("silo8.jpg").convert()
	imageSilo9 = pygame.image.load("silo9.jpg").convert()
	imageSilo10 = pygame.image.load("silo10.jpg").convert()
	imageSilo11 = pygame.image.load("silo11.jpg").convert()
	imageSilo12 = pygame.image.load("silo12.jpg").convert()
	listeimageSilo = [imageSiloVide, imageSilo1, imageSilo2, imageSilo3, imageSilo4, imageSilo5, imageSilo6, imageSilo7, imageSilo8, imageSilo9, imageSilo10, imageSilo11, imageSilo12]

	imageCaseVide = pygame.image.load("case.jpg").convert()
	imageCase1 = pygame.image.load("case1.jpg").convert()
	imageCase2 = pygame.image.load("case2.jpg").convert()
	imageCase3 = pygame.image.load("case3.jpg").convert()
	imageCase4 = pygame.image.load("case4.jpg").convert()
	imageCase5 = pygame.image.load("case5.jpg").convert()
	imageCase6 = pygame.image.load("case6.jpg").convert()
	imageCase7 = pygame.image.load("case7.jpg").convert()
	imageCase8 = pygame.image.load("case8.jpg").convert()
	imageCasex = pygame.image.load("casex.jpg").convert()
	listeimageCase = [imageCaseVide, imageCase1, imageCase2, imageCase3, imageCase4, imageCase5, imageCase6, imageCase7, imageCase8, imageCasex]

	imageNumeroCase1Joueur = pygame.image.load("1.jpg").convert()
	imageNumeroCase2Joueur = pygame.image.load("2.jpg").convert()
	imageNumeroCase3Joueur = pygame.image.load("3.jpg").convert()
	imageNumeroCase4Joueur = pygame.image.load("4.jpg").convert()
	imageNumeroCase5Joueur = pygame.image.load("5.jpg").convert()
	imageNumeroCase6Joueur = pygame.image.load("6.jpg").convert()
	imageNumeroCase7Joueur = pygame.image.load("7.jpg").convert()
	imageNumeroCase8Joueur = pygame.image.load("8.jpg").convert()
	imageNumeroCase9Joueur = pygame.image.load("9.jpg").convert()
	listeimageNumeroCaseJoueur = [imageNumeroCase1Joueur, imageNumeroCase2Joueur, imageNumeroCase3Joueur, imageNumeroCase4Joueur, imageNumeroCase5Joueur, imageNumeroCase6Joueur, imageNumeroCase7Joueur, imageNumeroCase8Joueur, imageNumeroCase9Joueur, imageNumeroCase1Joueur]

	imageJoueur1 = pygame.image.load("J1.jpg").convert()
	imageJoueur2 = pygame.image.load("J2.jpg").convert()

	fenetre.blit(imageSiloVide, (50,50))
	for n in range ((int(options['c']))):
		fenetre.blit(pygame.transform.rotate(listeimageNumeroCaseJoueur[(int(options['c']))- n - 1], 180), (origineX+largeurCase+15+largeurCase*n,10))
		fenetre.blit(listeimageCase[int(options['g'])], (origineX+(n+1)*largeurCase,origineY))
		fenetre.blit(listeimageCase[int(options['g'])], (origineX+(n+1)*largeurCase,origineY+hauteurCase))
		fenetre.blit(listeimageNumeroCaseJoueur[n], (origineX+largeurCase+15+largeurCase*n,origineY+hauteurCase*2+10))
	fenetre.blit(imageSiloVide, (origineX+(int(options['c'])+1)*largeurCase,origineY))
	fenetre.blit(imageJoueur1, (origineX+largeurCase*(int(options['c'])+1),origineY+hauteurCase*2+10))
	pygame.display.flip()

        # creation du plateau
	p = Plateau(int(options['c']), int(options['g']), options['r'])

	# Boucle d'évènements
	pygame.time.Clock().tick(30)
	while p.finDuJeu == False:
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				sys.exit()
			if event.type == pygame.MOUSEBUTTONDOWN:
				if (pygame.mouse.get_pos()[0] < 100 or pygame.mouse.get_pos()[0] > 100 + int(options['c'])*largeurCase):
					continue
				if DEBUG:
					print ("Joueur = ", p.numeroJoueur+1) 
				pos = (pygame.mouse.get_pos()[0], pygame.mouse.get_pos()[1])
				if DEBUG:
					print (pos) 

				if p.numeroJoueur == 0: #joueur 1
					if DEBUG:
						print ( int((pygame.mouse.get_pos()[0]-100)/largeurCase) )
					p.tourDeJeu( int((pygame.mouse.get_pos()[0]-100)/largeurCase) )
				else: #joueur 2
					if DEBUG:
						print ( int(options['c']) - 1 - int( (pygame.mouse.get_pos()[0]-100)/largeurCase) )
					p.tourDeJeu( int(options['c']) - 1 - int( (pygame.mouse.get_pos()[0]-100)/largeurCase) )

				# affichage plateau-----------------
				fenetre.blit(fond, (0,0))
				label = myfont.render(str(p.Silos[1].graines), 1, (0,0,0))
				fenetre.blit(label, (1, 118))
				if p.Silos[1].graines > 12:
					fenetre.blit(imageSilo12, (origineX,origineY))
				else:
					fenetre.blit(listeimageSilo[p.Silos[1].graines], (origineX,50))
				for n in range ((int(options['c']))):
					fenetre.blit(pygame.transform.rotate(listeimageNumeroCaseJoueur[(int(options['c']))- n - 1], 180), (origineX+largeurCase+15+largeurCase*n,10))
					if p.Cases[1][int(options['c'])-n-1].graines > 8:
						fenetre.blit(imageCasex, (origineX+(n+1)*largeurCase,origineY))
					else :
						fenetre.blit(listeimageCase[p.Cases[1][int(options['c'])-n-1].graines], (origineX+(n+1)*largeurCase,origineY))
					if p.Cases[0][n].graines > 8:
						fenetre.blit(imageCasex, (origineX+(n+1)*largeurCase,origineY+hauteurCase))
					else:
						fenetre.blit(listeimageCase[p.Cases[0][n].graines], (origineX+(n+1)*largeurCase,origineY+hauteurCase))
					fenetre.blit(listeimageNumeroCaseJoueur[n], (origineX+largeurCase+15+largeurCase*n,origineY+hauteurCase*2+10))
				if p.Silos[0].graines > 12:
					fenetre.blit(imageSilo12, (origineX+(int(options['c'])+1)*largeurCase,origineY))
				else :
					fenetre.blit(listeimageSilo[p.Silos[0].graines], (origineX+(int(options['c'])+1)*largeurCase,origineY))
				label = myfont.render(str(p.Silos[0].graines), 1, (0,0,0))
				fenetre.blit(label, (origineX+(int(options['c'])+2)*largeurCase, 120))
				if p.numeroJoueur == 0:
					fenetre.blit(imageJoueur1, (origineX+largeurCase*(int(options['c'])+1),origineY+hauteurCase*2+10))
				else:
					fenetre.blit(imageJoueur2, (0,10))
				pygame.display.flip() 

        # fin du jeu
	if p.Silos[0].graines > p.Silos[1].graines:
		fenetre.blit(imageJoueur1, (250,260))
		label = myfont.render('GAGNE !!!', 1, (0,0,0))
	else:
		fenetre.blit(imageJoueur2, (250,260))
		label = myfont.render('GAGNE !!!', 1, (0,0,0))
	fenetre.blit(label, (390, 260))
	pygame.display.flip()


# A FAIRE Pas affamer adversaire

# ------------------------------------------------------------------------------
if __name__ == '__main__':
  main()
# ==============================================================================
