Projet Mancala version finale
GILLIARD Tallulah G2
Le jeu Mancala ci contre existe avec l'interface graphique pygame.
On consid�re que les joueurs ne jouent pas dans leurs silo.
Les r�gles �nonc�es dans les consignes de d�part sont respect�es.
Il existe trois options modifiables par l'utilisateur (nombre de graines, nombres de cases et r�gle du jeu)