"""Constantes du jeu de Lego Minautore"""

#Parametres de la fenetre
nombre_sprite_cote = 32
taille_sprite = 20
cote_fenetre = nombre_sprite_cote * taille_sprite

#Personnalisation de la fenetre
titre_fenetre = "Minautorus"
image_icone = "images/Aquamini.jpg"

#Listes des images du jeu
image_accueil = "images/Start.jpg"
image_reglejeu = "images/ReglesJeu.png"
image_fond1 = "images/fond_lego.jpg"
image_fond2 = "images/fond_aqua.jpg"
image_mur = "images/mur.png"
image_mur2 = "images/bulle.png"
image_barriere = "images/barriere.png"
image_depart1 = "images/base1.png"
image_arrivee1 = "images/temple1.png"
image_depart2 = "images/base2.png"
image_arrivee2 = "images/temple2.png"
image_depart3 = "images/base3.png"
image_arrivee3 = "images/temple3.png"
image_depart4 = "images/base4.png"
image_arrivee4 = "images/temple4.png"
image_de_un = "images/de_un.jpg"
image_de_deux = "images/de_deux.jpg"
image_de_trois = "images/de_trois.jpg"
image_de_quatre = "images/de_quatre.jpg"
image_de_cinq = "images/de_cinq.jpg"
image_de_six = "images/de_six.jpg"
image_winner1 = "images/win1.png"
image_winner2 = "images/win2.png"
image_winner3 = "images/win3.png"
image_winner4 = "images/win4.png"
