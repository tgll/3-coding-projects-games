#!/usr/bin/python3 # -*- coding: Utf-8 -*

"""
Lego Minotaure
Jeu dans lequel on doit déplacer les joueurs a travers un labyrinthe.
Ils doivent arriver a leurs temples en premiers sans croiser le Minotaure, gardien du labyrinthe.

Script Python
Fichiers : LegoMinotaure.py, classes.py, constantes.py, n1, n2 + images
"""

import random
import pygame
import pickle
from pygame.locals import *

from classes import *
from constantes import *

pygame.init()

nbjoueur = 4

#Ouverture de la fenêtre Pygame (carré : largeur = hauteur)
fenetre = pygame.display.set_mode((cote_fenetre, cote_fenetre))
#Icone
icone = pygame.image.load(image_icone)
pygame.display.set_icon(icone)
#Titre
pygame.display.set_caption(titre_fenetre)

#BOUCLE PRINCIPALE
continuer = 1
while continuer:        
        #Chargement et affichage de l'écran d'accueil
        accueil = pygame.image.load(image_accueil).convert()
        fenetre.blit(accueil, (0,0))

        #Rafraichissement
        pygame.display.flip()

        #On remet ces variables à 1 à chaque tour de boucle
        continuer_jeu = 1
        continuer_accueil = 1

        #Demarage - Ecran d accueil 
        continuer_accueil = 1
        while continuer_accueil:
        #begin
                #Limitation de vitesse de la boucle pour alleger le processeur en calculs
                pygame.time.Clock().tick(30)
                
                for event in pygame.event.get():
                
                        if event.type == KEYDOWN:                               
                                #Lancement du niveau 1
                                if event.key == K_F1:
                                        choix = 'n1'            #On définit le niveau à charger
                                        fond = pygame.image.load(image_fond1).convert() #Chargement du fond
                                        continuer_accueil = 0
                                #Lancement du niveau 2
                                elif event.key == K_F2:
                                        choix = 'n2'
                                        fond = pygame.image.load(image_fond2).convert() #Chargement du fond
                                        continuer_accueil = 0
                                elif event.key == K_r:
                                        fenetre.blit(pygame.image.load(image_reglejeu).convert(), (0,0))
                                        pygame.display.flip()

                                        tempo = 1
                                        while tempo == 1:
                                                for event in pygame.event.get():
                                                        if event.type == QUIT or event.type == KEYDOWN:
                                                                tempo = 0
                                        fenetre.blit(accueil, (0,0))
                                        pygame.display.flip()
                                elif event.key == K_ESCAPE:
                                        continuer = 0
                                        continuer_accueil = 0
                                        break
        #end

        #Génération d'un niveau à partir d'un fichier
        niveau = Niveau(choix)
        niveau.generer()
        niveau.afficher(fenetre)

        #Chargement image des des
        de = [pygame.image.load(image_de_un).convert(),
              pygame.image.load(image_de_deux).convert(),
              pygame.image.load(image_de_trois).convert(),
              pygame.image.load(image_de_quatre).convert(),
              pygame.image.load(image_de_cinq).convert(),
              pygame.image.load(image_de_six).convert()]

        #Création des 4 Joueurs et du Minotaure et positionnements
        J1_1 = Joueur("images/J1_droite.png",niveau)
        J1_1.case_x = 1
        J1_1.case_y = 1
        J1_1.x = 1 * taille_sprite
        J1_1.y = 1 * taille_sprite

        J1_2 = Joueur("images/J1_droite.png",niveau)
        J1_2.case_x = 1
        J1_2.case_y = 2
        J1_2.x = 1 * taille_sprite
        J1_2.y = 2 * taille_sprite

        J1_3 = Joueur("images/J1_droite.png",niveau)
        J1_3.case_x = 2
        J1_3.case_y = 1
        J1_3.x = 2 * taille_sprite
        J1_3.y = 1 * taille_sprite        

        J2_1 = Joueur("images/J2.png", niveau)
        J2_1.case_x = 30
        J2_1.case_y = 1
        J2_1.x = 30 * taille_sprite
        J2_1.y = 1 * taille_sprite

        J2_2 = Joueur("images/J2.png", niveau)
        J2_2.case_x = 30
        J2_2.case_y = 2
        J2_2.x = 30 * taille_sprite
        J2_2.y = 2 * taille_sprite

        J2_3 = Joueur("images/J2.png", niveau)
        J2_3.case_x = 29
        J2_3.case_y = 1
        J2_3.x = 29 * taille_sprite
        J2_3.y = 1 * taille_sprite

        J3_1 = Joueur("images/J3.png", niveau)
        J3_1.case_x = 1
        J3_1.case_y = 30
        J3_1.x = 1 * taille_sprite
        J3_1.y = 30 * taille_sprite

        J3_2 = Joueur("images/J3.png", niveau)
        J3_2.case_x = 2
        J3_2.case_y = 30
        J3_2.x = 2 * taille_sprite
        J3_2.y = 30 * taille_sprite

        J3_3 = Joueur("images/J3.png", niveau)
        J3_3.case_x = 1
        J3_3.case_y = 29
        J3_3.x = 1 * taille_sprite
        J3_3.y = 29 * taille_sprite

        J4_1 = Joueur("images/J4.png", niveau)
        J4_1.case_x = 30
        J4_1.case_y = 30
        J4_1.x = 30 * taille_sprite
        J4_1.y = 30 * taille_sprite

        J4_2 = Joueur("images/J4.png", niveau)
        J4_2.case_x = 29
        J4_2.case_y = 30
        J4_2.x = 29 * taille_sprite
        J4_2.y = 30 * taille_sprite

        J4_3 = Joueur("images/J4.png", niveau)
        J4_3.case_x = 30
        J4_3.case_y = 29
        J4_3.x = 30 * taille_sprite
        J4_3.y = 29 * taille_sprite

        Mino = Joueur("images/Minotaure.png", niveau)
        Mino.case_x = 15
        Mino.case_y = 14
        Mino.x = 15 * taille_sprite
        Mino.y = 14 * taille_sprite

        joueur1 = [J1_1, J1_2, J1_3]
        joueur2 = [J2_1, J2_2, J2_3]
        joueur3 = [J3_1, J3_2, J3_3]
        joueur4 = [J4_1, J4_2, J4_3]
        Minotaure = [Mino, Mino, Mino]
        joueur = [joueur1, joueur2, joueur3, joueur4, Minotaure]

        pion_arrive = [0, 0, 0, 0]

        
        #BOUCLE DE JEU
        while continuer_jeu:
        #begin
                #Limitation de vitesse de la boucle pour alleger le processeur en calculs
                pygame.time.Clock().tick(30)

                numero_joueur = 1
                pion_selectionne = 0
                print "nouveau tour numero_joueur=",numero_joueur

                # pour chaque joueur
                while numero_joueur <= nbjoueur and continuer_jeu == 1:
                #begin
                        #lance du de
                        tirage_de = random.randint(1,6)
                        print ("tirage= ", tirage_de)
                        
                        if tirage_de == 1:
                                print "barrieres"
                                #Affichages aux nouvelles positions
                                fenetre.blit(fond, (0,0))
                                niveau.afficher(fenetre)
                                for i in range (4):
                                        for j in range (3):
                                                fenetre.blit(joueur[i][j].sprite, (joueur[i][j].x, joueur[i][j].y)) 
                                fenetre.blit(Mino.sprite, (Mino.x, Mino.y)) 
                                if numero_joueur == 1 or numero_joueur == 2:
                                    fenetre.blit(de[tirage_de-1],((numero_joueur-1)*(nombre_sprite_cote-1)*taille_sprite,0)) #affichage de
                                if numero_joueur == 3 or numero_joueur == 4:
                                    fenetre.blit(de[tirage_de-1],((numero_joueur-3)*(nombre_sprite_cote-1)*taille_sprite,(nombre_sprite_cote-1)*taille_sprite))
                                pygame.display.flip()

                                deplacement_barriere = 1
                                while deplacement_barriere:
                                        for event in pygame.event.get():
                                                if event.type==MOUSEBUTTONDOWN:
                                                        mousex, mousey = pygame.mouse.get_pos()
                                                        if niveau.matrice[mousey/taille_sprite][mousex/taille_sprite] == 'M':
                                                                print "mur"
                                                                print mousex, mousey
                                                                if niveau.matrice[mousey/taille_sprite-1][mousex/taille_sprite] == 'M':
                                                                        niveau.matrice[mousey/taille_sprite-1][mousex/taille_sprite] = '0'
                                                                        niveau.matrice[mousey/taille_sprite][mousex/taille_sprite] = '0'
                                                                        barriere_verticale = 1
                                                                elif niveau.matrice[mousey/taille_sprite+1][mousex/taille_sprite] == 'M':
                                                                        niveau.matrice[mousey/taille_sprite+1][mousex/taille_sprite] = '0'
                                                                        niveau.matrice[mousey/taille_sprite][mousex/taille_sprite] = '0'
                                                                        barriere_verticale = 1
                                                                elif niveau.matrice[mousey/taille_sprite][mousex/taille_sprite-1] == 'M':
                                                                        niveau.matrice[mousey/taille_sprite][mousex/taille_sprite-1] = '0'
                                                                        niveau.matrice[mousey/taille_sprite][mousex/taille_sprite] = '0'
                                                                        barriere_verticale = 0
                                                                elif niveau.matrice[mousey/taille_sprite][mousex/taille_sprite+1] == 'M':
                                                                        niveau.matrice[mousey/taille_sprite][mousex/taille_sprite+1] = '0'
                                                                        niveau.matrice[mousey/taille_sprite][mousex/taille_sprite] = '0'
                                                                        barriere_verticale = 0
                                                                deplacement_barriere = 0
                                barriere_posee = 0
                                while barriere_posee == 0:
                                        for event in pygame.event.get():
                                                if event.type==MOUSEBUTTONDOWN:
                                                        mousex, mousey = pygame.mouse.get_pos()
                                                        if niveau.matrice[mousey/taille_sprite][mousex/taille_sprite] == '0':
                                                                if barriere_verticale:
                                                                        if niveau.matrice[mousey/taille_sprite-1][mousex/taille_sprite] == '0':
                                                                                niveau.matrice[mousey/taille_sprite][mousex/taille_sprite] = 'M'
                                                                                niveau.matrice[mousey/taille_sprite-1][mousex/taille_sprite] = 'M'
                                                                                barriere_posee = 1
                                                                        elif niveau.matrice[mousey/taille_sprite+1][mousex/taille_sprite] == '0':
                                                                                niveau.matrice[mousey/taille_sprite][mousex/taille_sprite] = 'M'
                                                                                niveau.matrice[mousey/taille_sprite+1][mousex/taille_sprite] = 'M'
                                                                                barriere_posee = 1
                                                                else:
                                                                        if niveau.matrice[mousey/taille_sprite][mousex/taille_sprite-1] == '0':
                                                                                niveau.matrice[mousey/taille_sprite][mousex/taille_sprite] = 'M'
                                                                                niveau.matrice[mousey/taille_sprite][mousex/taille_sprite-1] = 'M'
                                                                                barriere_posee = 1
                                                                        elif niveau.matrice[mousey/taille_sprite][mousex/taille_sprite+1] == '0':
                                                                                niveau.matrice[mousey/taille_sprite][mousex/taille_sprite] = 'M'
                                                                                niveau.matrice[mousey/taille_sprite][mousex/taille_sprite+1] = 'M'
                                                                                barriere_posee = 1                                                                
                                                                print "mur posee"
                                                                                                                              
                                                                
                                
                        elif tirage_de == 2 or tirage_de == 3 or tirage_de == 4 or tirage_de == 5 or tirage_de == 6:
                        #begin
                                sauve_joueur = numero_joueur
                                if tirage_de == 6: #MINOTAURE
                                    deplacement_tirage_de = 8
                                    numero_joueur = 5 #c est le minotaure
                                else:
                                    deplacement_tirage_de = tirage_de

                                #pour le nombre de case a jouer par le joueur suivant le tirage du de
                                deplacement = 1
                                while deplacement <= deplacement_tirage_de and continuer_jeu == 1:
                                #begin
                                        for event in pygame.event.get():
                                                #selection d un des trois pions
                                                if event.type==MOUSEBUTTONDOWN:
                                                        mousex, mousey = pygame.mouse.get_pos()
                                                        if joueur[0][0].case_x == mousex/taille_sprite and joueur[0][0].case_y == mousey/taille_sprite:
                                                                print "joueur1-1"
                                                                pion_selectionne = 0
                                                        elif joueur[0][1].case_x == mousex/taille_sprite and joueur[0][1].case_y == mousey/taille_sprite:
                                                                print "joueur1-2"
                                                                pion_selectionne = 1
                                                        elif joueur[0][2].case_x == mousex/taille_sprite and joueur[0][2].case_y == mousey/taille_sprite:
                                                                print "joueur1-3"
                                                                pion_selectionne = 2
                                                        elif joueur[1][0].case_x == mousex/taille_sprite and joueur[1][0].case_y == mousey/taille_sprite:
                                                                print "joueur2-1"
                                                                pion_selectionne = 0
                                                        elif joueur[1][1].case_x == mousex/taille_sprite and joueur[1][1].case_y == mousey/taille_sprite:
                                                                print "joueur2-2"
                                                                pion_selectionne = 1
                                                        elif joueur[1][2].case_x == mousex/taille_sprite and joueur[1][2].case_y == mousey/taille_sprite:
                                                                print "joueur2-3"
                                                                pion_selectionne = 2
                                                        elif joueur[2][0].case_x == mousex/taille_sprite and joueur[2][0].case_y == mousey/taille_sprite:
                                                                print "joueur3-1"
                                                                pion_selectionne = 0
                                                        elif joueur[2][1].case_x == mousex/taille_sprite and joueur[2][1].case_y == mousey/taille_sprite:
                                                                print "joueur3-2"
                                                                pion_selectionne = 1
                                                        elif joueur[2][2].case_x == mousex/taille_sprite and joueur[2][2].case_y == mousey/taille_sprite:
                                                                print "joueur3-3"
                                                                pion_selectionne = 2
                                                        elif joueur[3][0].case_x == mousex/taille_sprite and joueur[3][0].case_y == mousey/taille_sprite:
                                                                print "joueur4-1"
                                                                pion_selectionne = 0
                                                        elif joueur[3][1].case_x == mousex/taille_sprite and joueur[3][1].case_y == mousey/taille_sprite:
                                                                print "joueur4-2"
                                                                pion_selectionne = 1
                                                        elif joueur[3][2].case_x == mousex/taille_sprite and joueur[3][2].case_y == mousey/taille_sprite:
                                                                print "joueur4-3"
                                                                pion_selectionne = 2
                                                        #le bloc pourrait etre regroupe en testant avec un or les 4 cas pion_selectionne = 0 puis = 1 puis =2.
                                                        #mais le laisser tel que ci dessus rend la lecture plus simple 
                                                        
                                                #Si l'utilisateur quitte, on met la variable qui continue le jeu
                                                #Et la variable générale à 0 pour fermer la fenêtre
                                                if event.type == QUIT:
                                                        continuer_jeu = 0
                                                        continuer = 0
                                        
                                                elif event.type == KEYDOWN:
                                                        #Si l'utilisateur presse Echap ici, on revient seulement au menu
                                                        if event.key == K_ESCAPE:
                                                                continuer_jeu = 0

                                                        elif event.key == K_s: #(s)auve 
                                                                #sauvegarder la partie
                                                                with open('sauvegarde', 'wt') as fichier:
                                                                        mon_pickler = pickle.Pickler(fichier)
                                                                        for i in range (4):
                                                                                for j in range (3):
                                                                                        mon_pickler.dump(joueur[i][j].case_x)
                                                                                        mon_pickler.dump(joueur[i][j].case_y)                                                                        
                                                                        mon_pickler.dump(Mino.case_x)
                                                                        mon_pickler.dump(Mino.case_y)
                                                                        mon_pickler.dump(numero_joueur)
                                                                        mon_pickler.dump(deplacement)
                                                                        mon_pickler.dump(sauve_joueur)
                                                                        mon_pickler.dump(pion_arrive)
                                                                        print "Sauvegarde"

                                                        elif event.key == K_c or event.key == K_l: #(c)harge ou (l)oad
                                                                #charger la sauvegarde
                                                                with open('sauvegarde', 'rt') as fichier:
                                                                        mon_depickler = pickle.Unpickler(fichier)
                                                                        for i in range (4):
                                                                                for j in rrange (3):
                                                                                        joueur[i][j].case_x = mon_depickler.load()
                                                                                        joueur[i][j].case_y = mon_depickler.load()                                                                        
                                                                                        joueur[i][j].x = joueur[i][j].case_x * taille_sprite
                                                                                        joueur[i][j].y = joueur[i][j].case_y * taille_sprite
                                                                        Mino.case_x = mon_depickler.load()
                                                                        Mino.case_y = mon_depickler.load()
                                                                        Mino.x = Mino.case_x * taille_sprite
                                                                        Mino.y = Mino.case_y * taille_sprite 
                                                                        numero_joueur = mon_depickler.load()
                                                                        deplacement = mon_depickler.load()
                                                                        sauve_joueur = mon_depickler.load()
                                                                        pion_arrivee = mon_depickler.load()
                                                                        print "charge"
                                                                
                                                        #Touches de déplacement du joueur
                                                        elif event.key == K_RIGHT:
                                                                joueur[numero_joueur-1][pion_selectionne].deplacer('droite')
                                                                deplacement += 1
                                                        elif event.key == K_LEFT:
                                                                joueur[numero_joueur-1][pion_selectionne].deplacer('gauche')
                                                                deplacement += 1                                                                
                                                        elif event.key == K_UP:
                                                                joueur[numero_joueur-1][pion_selectionne].deplacer('haut')
                                                                deplacement += 1                                                                
                                                        elif event.key == K_DOWN:
                                                                joueur[numero_joueur-1][pion_selectionne].deplacer('bas')
                                                                deplacement += 1
                                                
                                        #Affichages aux nouvelles positions
                                        fenetre.blit(fond, (0,0))
                                        niveau.afficher(fenetre)
                                        for i in range (4):
                                                for j in range (3):
                                                        fenetre.blit(joueur[i][j].sprite, (joueur[i][j].x, joueur[i][j].y))                                         
                                        fenetre.blit(Mino.sprite, (Mino.x, Mino.y)) 
                                        if sauve_joueur == 1 or sauve_joueur == 2:
                                            fenetre.blit(de[tirage_de-1],((sauve_joueur-1)*(nombre_sprite_cote-1)*taille_sprite,0)) #affichage de
                                        if sauve_joueur == 3 or sauve_joueur == 4:
                                            fenetre.blit(de[tirage_de-1],((sauve_joueur-3)*(nombre_sprite_cote-1)*taille_sprite,(nombre_sprite_cote-1)*taille_sprite))
                                        pygame.display.flip()

                                        #Victoire -> Retour à l'accueil

                                        if numero_joueur-1 == 0 and niveau.matrice[joueur[0][pion_selectionne].case_y][joueur[0][pion_selectionne].case_x] == 'A':
                                                if pion_arrive[0] == 0:           #aucun pion deja arrive
                                                        pion_arrive[0] = pion_selectionne + 1
                                                else:                                           #un pion deja arrive
                                                        if pion_selectionne+1 <> pion_arrive[0]:#si c est un pion non deja arrive
                                                                continuer_jeu = 0
                                        elif numero_joueur-1 == 1 and niveau.matrice[joueur[1][pion_selectionne].case_y][joueur[1][pion_selectionne].case_x] == 'B':
                                                if pion_arrive[1] == 0:           #aucun pion deja arrive
                                                        pion_arrive[1] = pion_selectionne + 1
                                                else:                                           #un pion deja arrive
                                                        if pion_selectionne+1 <> pion_arrive[1]:#si c est un pion non deja arrive
                                                                continuer_jeu = 0
                                        elif numero_joueur-1 == 2 and niveau.matrice[joueur[2][pion_selectionne].case_y][joueur[2][pion_selectionne].case_x] == 'C':
                                                if pion_arrive[2] == 0:           #aucun pion deja arrive
                                                        pion_arrive[2] = pion_selectionne + 1
                                                else:                                           #un pion deja arrive
                                                        if pion_selectionne+1 <> pion_arrive[2]:#si c est un pion non deja arrive
                                                                continuer_jeu = 0
                                        elif numero_joueur-1 == 3 and niveau.matrice[joueur[3][pion_selectionne].case_y][joueur[3][pion_selectionne].case_x] == 'D':
                                                if pion_arrive[3] == 0:           #aucun pion deja arrive
                                                        pion_arrive[3] = pion_selectionne + 1
                                                else:                                           #un pion deja arrive
                                                        if pion_selectionne+1 <> pion_arrive[3]:#si c est un pion non deja arrive
                                                                continuer_jeu = 0                                        
                                
                                        #Rencontre avec le Minotaure -> Retour à la case depart
                                        if joueur[0][pion_selectionne].case_x == joueur[4][0].case_x and joueur[0][pion_selectionne].case_y == joueur[4][0].case_y:
                                                joueur[0][pion_selectionne].case_x = 1
                                                joueur[0][pion_selectionne].case_y = 1
                                                joueur[0][pion_selectionne].x = 1 * taille_sprite
                                                joueur[0][pion_selectionne].y = 1 * taille_sprite
                                        elif joueur[1][pion_selectionne].case_x == joueur[4][0].case_x and joueur[1][pion_selectionne].case_y == joueur[4][0].case_y:
                                                joueur[1][pion_selectionne].case_x = 30
                                                joueur[1][pion_selectionne].case_y = 1
                                                joueur[1][pion_selectionne].x = 30 * taille_sprite
                                                joueur[1][pion_selectionne].y = 1 * taille_sprite                                               
                                        elif joueur[2][pion_selectionne].case_x == joueur[4][0].case_x and joueur[2][pion_selectionne].case_y == joueur[4][0].case_y:
                                                joueur[2][pion_selectionne].case_x = 1
                                                joueur[2][pion_selectionne].case_y = 30
                                                joueur[2][pion_selectionne].x = 1 * taille_sprite
                                                joueur[2][pion_selectionne].y = 30 * taille_sprite
                                        elif joueur[3][pion_selectionne].case_x == joueur[4][0].case_x and joueur[3][pion_selectionne].case_y == joueur[4][0].case_y:
                                                joueur[3][pion_selectionne].case_x = 30
                                                joueur[3][pion_selectionne].case_y = 30
                                                joueur[3][pion_selectionne].x = 30 * taille_sprite
                                                joueur[3][pion_selectionne].y = 30 * taille_sprite                                              
                                #end
                                if tirage_de == 6:      #fin tour minotaure
                                    numero_joueur = sauve_joueur
                        #end
                        """ fin boucle déplacement de 2 a 6 """
                        numero_joueur += 1                 #joueur suivant
                        print "numero_joueur=",numero_joueur
                #end
                """ fin boucle pour chaque joueur """
        #end
        """ fin de la boucle du jeu """
        print "gagnant", numero_joueur-1
        if numero_joueur-1 == 1:
                winner = pygame.image.load(image_winner1).convert()
        elif numero_joueur-1 == 2:
                winner = pygame.image.load(image_winner2).convert()        
        elif numero_joueur-1 == 3:
                winner = pygame.image.load(image_winner3).convert()
        elif numero_joueur-1 == 4:
                winner = pygame.image.load(image_winner4).convert()                   
        fenetre.blit(winner, (0,0))

        pygame.display.flip()
        tempo = 1
        while tempo == 1:
                for event in pygame.event.get():
                        if event.type == QUIT or event.type == KEYDOWN:
                                tempo = 0

