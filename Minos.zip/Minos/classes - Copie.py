"""Classes du jeu de Lego Minotaure"""

import pygame
from pygame.locals import *
from constantes import *

class Niveau:
	"""Classe permettant de creer un niveau"""
	def __init__(self, fichier):
		self.fichier = fichier
		self.matrice = 0


	def generer(self):
		"""Methode permettant de generer le niveau en fonction du fichier.
		On cree une liste generale, contenant une liste par ligne a afficher"""
		#On ouvre le fichier
		with open(self.fichier, "r") as fichier:
			matrice_niveau = []
			#On parcourt les lignes du fichier
			for ligne in fichier:
				ligne_niveau = []
				#On parcourt les sprites (lettres) contenus dans le fichier
				for sprite in ligne:
					#On ignore les "\n" de fin de ligne
					if sprite != '\n':
						#On ajoute le sprite a la liste de la ligne
						ligne_niveau.append(sprite)
				#On ajoute la ligne a la liste du niveau
				matrice_niveau.append(ligne_niveau)
			#On sauvegarde cette structure
			self.matrice = matrice_niveau


	def afficher(self, fenetre):
		"""Methode permettant d'afficher le niveau en fonction
		de la liste de structure renvoyee par generer()"""
		#Chargement des images 
		mur = pygame.image.load(image_mur).convert()
		barriere = pygame.image.load(image_barriere).convert()
		depart1 = pygame.image.load(image_depart1).convert()
		arrivee1 = pygame.image.load(image_arrivee1).convert()
		depart2 = pygame.image.load(image_depart2).convert()
		arrivee2 = pygame.image.load(image_arrivee2).convert()
		depart3 = pygame.image.load(image_depart3).convert()
		arrivee3 = pygame.image.load(image_arrivee3).convert()
		depart4 = pygame.image.load(image_depart4).convert()
		arrivee4 = pygame.image.load(image_arrivee4).convert()
		
		#On parcourt la liste du niveau
		num_ligne = 0
		for ligne in self.matrice:
			#On parcourt les listes de lignes
			num_case = 0
			for sprite in ligne:
				#On calcule la position reelle en pixels
				x = num_case * taille_sprite
				y = num_ligne * taille_sprite
				if sprite == 'm':		   #m = Mur
					fenetre.blit(mur, (x,y))
				elif sprite == 'M':		   #M = Barriere
					fenetre.blit(barriere, (x,y))
				elif sprite == 'a':		   #a = Depart1
					fenetre.blit(depart1, (x,y))
				elif sprite == 'b':		   #b = Depart2
					fenetre.blit(depart2, (x,y))
				elif sprite == 'c':		   #c = Depart3
					fenetre.blit(depart3, (x,y))
				elif sprite == 'd':		   #d = Depart4
					fenetre.blit(depart4, (x,y))					
				elif sprite == 'A':		   #A = Arrivee1
					fenetre.blit(arrivee1, (x,y))
				elif sprite == 'B':		   #B = Arrivee2
					fenetre.blit(arrivee2, (x,y))
				elif sprite == 'C':		   #C = Arrivee3
					fenetre.blit(arrivee3, (x,y))
				elif sprite == 'D':		   #D = Arrivee4
					fenetre.blit(arrivee4, (x,y))					
				num_case += 1
			num_ligne += 1




class Joueur:
	"""Classe permettant de creer un personnage"""
	def __init__(self, droite, gauche, haut, bas, niveau):
		#Sprites du personnage
		self.droite = pygame.image.load(droite).convert()
		self.gauche = pygame.image.load(gauche).convert()
		self.haut = pygame.image.load(haut).convert()
		self.bas = pygame.image.load(bas).convert()
		#Position du personnage en cases et en pixels
		self.case_x = 0
		self.case_y = 0
		self.x = 0
		self.y = 0
                #Direction par defaut
		self.direction = self.droite
		#Niveau dans lequel le personnage se trouve
		self.niveau = niveau


	def deplacer(self, direction):
		"""Methode permettant de deplacer le personnage"""

		#Deplacement vers la droite
		if direction == 'droite':
			#Pour ne pas depasser l'ecran
			if self.case_x < (nombre_sprite_cote - 1):
				#On verifie que la case de destination n'est pas un mur ou une barriere
				if self.niveau.matrice[self.case_y][self.case_x+1] != 'm' and self.niveau.matrice[self.case_y][self.case_x+1] != 'M':
					#Deplacement d'une case
					self.case_x += 1
					#Calcul de la position "reelle" en pixel
					self.x = self.case_x * taille_sprite
			#Image dans la bonne direction et reaffichage(si plusieurs directions, ici ce n est pas le cas)
			self.direction = self.droite

		#Deplacement vers la gauche
		if direction == 'gauche':
			if self.case_x > 0:
				if self.niveau.matrice[self.case_y][self.case_x-1] != 'm' and self.niveau.matrice[self.case_y][self.case_x-1] != 'M':
					self.case_x -= 1
					self.x = self.case_x * taille_sprite
			self.direction = self.gauche

		#Deplacement vers le haut
		if direction == 'haut':
			if self.case_y > 0:
				if self.niveau.matrice[self.case_y-1][self.case_x] != 'm' and self.niveau.matrice[self.case_y-1][self.case_x] != 'M':
					self.case_y -= 1
					self.y = self.case_y * taille_sprite
			self.direction = self.haut

		#Deplacement vers le bas
		if direction == 'bas':
			if self.case_y < (nombre_sprite_cote - 1):
				if self.niveau.matrice[self.case_y+1][self.case_x] != 'm' and self.niveau.matrice[self.case_y+1][self.case_x] != 'M':
					self.case_y += 1
					self.y = self.case_y * taille_sprite
			self.direction = self.bas
