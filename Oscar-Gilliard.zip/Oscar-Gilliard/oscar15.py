# ==============================================================================
# OSCAR
# ==============================================================================
"""OSCAR """
__author__  = "Tallulah Gilliard"
__version__ = "1.0"
__date__    = "2015-12-12"
__usage__   = """
"""
# ==============================================================================

import pygame, sys, time, copy
from pygame.locals import *
from random import randint

DEBUG = False #active les print de controle pour le debug

class World:
    def __init__(self):
        self.nbCaseX = None
        self.nbCaseY = None
        self.tailleCaseX = 64
        self.tailleCaseY = 64
        self.imageCaseVide = None
        self.imageTrace = 'trace.png'
        self.fenetre = None
        self.background = None
        self.liste_images = []          # liste des images
        self.liste_modele_agents = []   # liste d'objets de type mineral, vegetal, animal - liste finie
        self.liste_agents = []          # liste d'agents - liste non finie (death et birth)
        self.liste_index_agents = []    # liste des noms d'agents
 
        
    def init_fenetre(self):
    # initialisation elements graphiques
        # defini la taille de la fenetre
        tailleFenetreX = self.tailleCaseX * self.nbCaseX
        tailleFenetreY = self.tailleCaseY * self.nbCaseY

        # initialisation pygame 
        pygame.init()
        self.fenetre = pygame.display.set_mode((tailleFenetreX, tailleFenetreY))
        pygame.display.set_caption("OSCAR")

        # definition des icones
        self.imageCaseVide = pygame.image.load(self.imageCaseVide).convert()
        self.imageTrace = pygame.image.load(self.imageTrace).convert_alpha()
        for i in range(len(self.liste_images)):
            if DEBUG: print(i, self.liste_images[i])
            mot = self.liste_images[i].split('.')
            self.liste_index_agents.append(mot[0]) # liste des noms d'agents
            self.liste_images[i] = pygame.image.load(self.liste_images[i]).convert_alpha() # liste des images
        self.background = pygame.Surface(self.fenetre.get_size())
        self.background = self.background.convert()
        self.background.fill((250, 250, 250))

    def affiche_fenetre(self):
        if DEBUG: print('AFFICHAGE-------------')
        self.fenetre.blit(self.background, (0, 0))
        for i in range(self.nbCaseX):
            # affichage des cases
            for j in range(self.nbCaseY):
                self.fenetre.blit(self.imageCaseVide, (i*self.tailleCaseX,j*self.tailleCaseY))
        for i in self.liste_agents:
            # affichage des traces
            if i.modele_agent.type == 'animal': 
                for j in range(0,len(i.modele_agent.traces)):
                    if DEBUG: print(len(i.modele_agent.traces),j,i.modele_agent.traces[j][0])
                    if i.modele_agent.traces[j][0] != -100:
                        if DEBUG: print(i.modele_agent.traces[j][0],i.modele_agent.traces[j][0]*self.tailleCaseX,i.modele_agent.traces[j][1],i.modele_agent.traces[j][1]*self.tailleCaseY)
                        self.fenetre.blit(self.imageTrace, (i.modele_agent.traces[j][0]*self.tailleCaseX, i.modele_agent.traces[j][1]*self.tailleCaseY))
            # affichage des agents
            self.fenetre.blit(self.liste_images[i.type_agent], (int(i.variables['agent']['xPosition'])*self.tailleCaseX,int(i.variables['agent']['yPosition'])*self.tailleCaseY))
        pygame.display.flip()        
        if DEBUG: print('-------------AFFICHAGE')

    def charge_world(self, fichier):
    # chargement des donnees du fichier
        self.file = open(fichier,'r')
        # controle sur nom du fichier
        texte_fichier = self.file.readlines() + ['\n']
        self.variables_agent = {}
        
        # analyse du fichier et creation des objets mineral, vegetal, animal et agent
        num_ligne = 0
        longueur_fichier = len(texte_fichier)
        ligne = texte_fichier[num_ligne]
        if DEBUG: print(longueur_fichier, num_ligne, ligne)
        
        while num_ligne < longueur_fichier-1: 
            if 'world ' in ligne :
                mots = ligne.split()
                self.nbCaseX = int(mots[1])
                self.nbCaseY = int(mots[2])
                self.imageCaseVide = mots[3]
                num_ligne+=1
                ligne = texte_fichier[num_ligne]
                if DEBUG: print('<world>',num_ligne, ligne)
                 
            if 'mineral ' in ligne:
                mots = ligne.split()
                self.variables_agent['mineral'] = {'statusName':mots[1], 'statusIcon':mots[2]}
                self.liste_images.append(mots[2])
                num_ligne+=1
                ligne = texte_fichier[num_ligne]
                if DEBUG: print('<mineral>',num_ligne, ligne)
                while ligne != '\n': # fin d un  bloc agent avec un saut de ligne
                    mots = ligne.split()
                    if 'var ' in ligne:
                        self.variables_agent['var'] = {'variable':int(mots[2]),'initValue':int(mots[2]),'stepValue':int(mots[3])}
                        if DEBUG: print('var')
                    if 'status ' in ligne:
                        self.variables_agent['status'] = {'variable':0,'signe':mots[2],'thresholdValue':int(mots[3]),'newStatus':mots[4]}
                        if DEBUG: print('status')
                    if 'field ' in ligne:
                        self.variables_agent['field'] = {'variable':mots[1],'decreaseValue':int(mots[2])}
                        if DEBUG: print('field')
                    if 'sensor ' in ligne:
                        self.variables_agent['sensor'] = {'variable':mots[1],'sensitivityValue':int(mots[2])}
                        if DEBUG: print('sensor')
                    if DEBUG: print('<mineral-variables>',num_ligne, ligne)
                    num_ligne+=1
                    ligne = texte_fichier[num_ligne]
                if DEBUG: print("DEBUG3")
                self.liste_modele_agents.append(Mineral(self.variables_agent))
                self.variables_agent = {}

            if DEBUG: print('DEBUG3')
                
            if 'vegetal ' in ligne:
                mots = ligne.split()
                self.variables_agent['vegetal'] = {'statusName':mots[1], 'statusIcon':mots[2]}
                self.liste_images.append(mots[2])
                num_ligne+=1
                ligne = texte_fichier[num_ligne]
                if DEBUG: print('<vegetal>',num_ligne, ligne)
                while ligne != '\n': # fin d un  bloc agent avec un saut de ligne
                    mots = ligne.split()
                    if 'var ' in ligne:
                        self.variables_agent['var'] = {'variable':int(mots[2]),'initValue':int(mots[2]),'stepValue':int(mots[3])}
                    if 'status ' in ligne:
                        self.variables_agent['status'] = {'variable':0,'signe':mots[2],'thresholdValue':int(mots[3]),'newStatus':mots[4]}
                    if 'birth ' in ligne:
                        self.variables_agent['birth'] = {'variable':0,'signe':mots[2],'thresholdValue':int(mots[3]),'newbornStatus':mots[4]}
                    if 'field ' in ligne:
                        self.variables_agent['field'] = {'variable':mots[1],'decreaseValue':int(mots[2])}
                    if 'sensor ' in ligne:
                        self.variables_agent['sensor'] = {'variable':mots[1],'sensitivityValue':int(mots[2])}
                    num_ligne += 1
                    ligne = texte_fichier[num_ligne]
                    if DEBUG: print('<vegetal-variables>',num_ligne, ligne)
                if DEBUG: print('DEBUG4')
                self.liste_modele_agents.append(Vegetal(self.variables_agent))
                self.variables_agent = {}
                if DEBUG: print('---------------------')
                
            if 'animal ' in ligne:
                mots = ligne.split()
                self.variables_agent['animal'] = {'statusName':mots[1], 'statusIcon':mots[2]}
                self.liste_images.append(mots[2])
                num_ligne+=1
                ligne = texte_fichier[num_ligne]
                if DEBUG: print('<animal>',num_ligne, ligne)
                while ligne != '\n': # fin d un  bloc agent avec un saut de ligne
                    mots = ligne.split()
                    if 'var ' in ligne:
                        self.variables_agent['var'] = {'variable':int(mots[2]),'initValue':int(mots[2]),'stepValue':int(mots[3])}
                    if 'status ' in ligne:
                        self.variables_agent['status'] = {'variable':0,'signe':mots[2],'thresholdValue':int(mots[3]),'newStatus':mots[4]}
                    if 'birth ' in ligne:
                        self.variables_agent['birth'] = {'variable':0,'signe':mots[2],'thresholdValue':int(mots[3]),'newbornStatus':mots[4]}
                    if 'trace ' in ligne:
                        self.variables_agent['trace'] = {'variable':mots[1],'signe':mots[2],'thresholdValue':int(mots[3]),'newtraceStatus':mots[4]}
                    if 'field ' in ligne:
                        self.variables_agent['field'] = {'variable':mots[1],'decreaseValue':int(mots[2])}
                    if 'sensor ' in ligne:
                        self.variables_agent['sensor'] = {'variable':mots[1],'sensitivityValue':int(mots[2])}
                    num_ligne += 1
                    ligne = texte_fichier[num_ligne]
                    if DEBUG: print('<animal-variables>',num_ligne, ligne)
                if DEBUG: print('DEBUG5')
                self.liste_modele_agents.append(Animal(self.variables_agent))
                self.variables_agent = {}
                
            if 'agent ' in ligne:
                mots = ligne.split()
                if DEBUG: print('>>>',mots[3])
                # calcul du type d'agent 
                type_agent = 0
                for i in self.liste_modele_agents:
                    if 'mineral' in i.variables:
                        if mots[3] in i.variables['mineral'].values():
                            if DEBUG: print('mineral')
                            break
                    elif 'vegetal' in i.variables:
                        if mots[3] in i.variables['vegetal'].values():
                            if DEBUG: print('vegetal')
                            break
                    elif 'animal' in i.variables:
                        if mots[3] in i.variables['animal'].values():
                            if DEBUG: print('animal')
                            break
                    type_agent += 1
                self.variables_agent['agent'] = {'xPosition':mots[1], 'yPosition':mots[2], 'initStatus':mots[3]}
                # creation d'un Agent avec son type, son dictionnaire de variables et la copie du dictionnaire de variables du modele type de l'agent
                self.liste_agents.append(Agent(type_agent, self.variables_agent, copy.deepcopy(self.liste_modele_agents[type_agent]))) 
                self.variables_agent = {}
                if DEBUG: print('DEBUG6')
                if DEBUG: print('---------------------')
            num_ligne+=1
            ligne = texte_fichier[num_ligne]
            if DEBUG: print('<fin>',num_ligne, ligne)

        if DEBUG: 
            print('---------------------')
            print('BILAN: \n')
            for i in range(len(self.liste_agents)):
                print(self.liste_agents[i].variables)
            print('\n')
            for i in range(len(self.liste_modele_agents)):
                print(self.liste_modele_agents[i].variables)
                print('---\n')
            print('---\n')

class Mineral():
    def __init__(self,dictionaire_mineral):
        self.variables = dictionaire_mineral
        self.type = 'mineral'
        # {mineral,var,status,field,sensor}
   
class Vegetal():
    def __init__(self,dictionaire_vegetal):
        self.variables = dictionaire_vegetal
        self.type = 'vegetal'
        # {vegetal,var,status,birth,field,sensor}
   
class Animal():
    def __init__(self,dictionaire_animal):
        self.variables = dictionaire_animal
        self.type = 'animal'
        self.traces = []
        # {vegetal,var,status,birth,trace,field,sensor}
   
class Agent():
    def __init__(self,type_agent,dictionaire_agent,modele_agent):
        self.type_agent = type_agent 
        self.variables = dictionaire_agent # dictionnaire des variables de l'agent
        self.modele_agent = modele_agent   # dictionnaire des variables du type d'agent
        # {agent}

class Oscar():
    def __init__(self, world):
        self.actif = True
        self.world = world
        self.field = []
        self.__initField__()

    def __modifieVar__(self,agent):
        if DEBUG: print('  Modifie var ',agent.modele_agent.variables['status']['variable'],' -> ',agent.modele_agent.variables['status']['variable'] + int(agent.modele_agent.variables['var']['stepValue']))
        agent.modele_agent.variables['status']['variable'] += int(agent.modele_agent.variables['var']['stepValue'])

    def __mortAgent__(self,agent):
        self.world.liste_agents.remove(agent)
        if DEBUG: print('      remove agent')
        if len(self.world.liste_agents) == 0: # tous les agents sont morts
            self.actif = False # pour arreter le jeu
            if DEBUG: print('Tous les agents sont morts')
            
    def __nouvelEtat__(self, agent):
        if DEBUG: print('    Nouvel Etat pour -',agent.variables['agent']['initStatus'],'>>',agent.modele_agent.variables['status']['newStatus'],'-')
        if agent.modele_agent.variables['status']['newStatus'] == 'DEATH':
            if DEBUG: print('      gere DEATH')
            self.__mortAgent__(agent)
        else :
            for i in self.world.liste_modele_agents:
                if type(i) == type(agent.modele_agent):
                    if agent.modele_agent.variables['status']['newStatus'] == i.variables[i.type]['statusName']:
                        if DEBUG: print('    NOUVEAU STATUS')
                        nouveau_status = i.variables[i.type]['statusName']
                        break
            agent.modele_agent = copy.deepcopy(i)
            agent.variables['agent']['initStatus'] = nouveau_status
            agent.type_agent = self.world.liste_index_agents.index(nouveau_status)
            if DEBUG: print('    Nouvel Etat : ',agent.variables['agent']['initStatus'],'[',agent.type_agent,']=',agent.modele_agent.variables['var']['variable'])

    def __testeStatus__(self, agent):
        if DEBUG: print('  Teste Status (',agent.modele_agent.variables['status']['variable'],')')
        if agent.modele_agent.variables['status']['signe'] == '>':
            if agent.modele_agent.variables['status']['variable'] > agent.modele_agent.variables['status']['thresholdValue']:
                self.__nouvelEtat__(agent)
        else:
            if agent.modele_agent.variables['status']['variable'] < agent.modele_agent.variables['status']['thresholdValue']:
                self.__nouvelEtat__(agent)

    def __naissanceAgent__(self,agent):
        nouvel_agent = {}
        meilleurXY = self.__meilleurSpot__(agent) 
        nouvel_agent['agent'] = {'xPosition':meilleurXY[0], 'yPosition':meilleurXY[1], 'initStatus':agent.modele_agent.variables['birth']['newbornStatus']}
        nouvel_type_agent = self.world.liste_index_agents.index(agent.modele_agent.variables['birth']['newbornStatus'])
        if DEBUG: print('  naissance ',self.world.liste_index_agents[nouvel_type_agent],'[',nouvel_type_agent,'] // ',nouvel_agent,' // ',self.world.liste_modele_agents[nouvel_type_agent])
        return Agent(nouvel_type_agent,nouvel_agent,copy.deepcopy(self.world.liste_modele_agents[nouvel_type_agent]))

    def __testeNaissance__(self,agent):
        if agent.modele_agent.type in ('animal','vegetal'):
            if DEBUG: print('  Teste naissance (',agent.modele_agent.variables['birth']['variable'],')')
            agent.modele_agent.variables['birth']['variable'] += agent.modele_agent.variables['var']['stepValue']
            if agent.modele_agent.variables['birth']['newbornStatus'] != 'IMPOSSIBLE':
                if agent.modele_agent.variables['birth']['signe'] == '>':
                    if agent.modele_agent.variables['birth']['variable'] > agent.modele_agent.variables['birth']['thresholdValue']:
                        self.world.liste_agents.append(self.__naissanceAgent__(agent))
                        agent.modele_agent.variables['birth']['variable'] = 0
                else:
                    if agent.modele_agent.variables['birth']['variable'] < agent.modele_agent.variables['birth']['thresholdValue']:
                        self.world.liste_agents.append(self.__naissanceAgent__(agent))
                        agent.modele_agent.variables['birth']['variable'] = 0

    def __gereTrace__(self, agent):
        if type(agent.modele_agent) == Animal:
            if DEBUG: print('  GereTrace : ',agent.modele_agent.traces)
            if len(agent.modele_agent.traces) == 0: # initialise la trace
                agent.modele_agent.traces = [(int(agent.variables['agent']['xPosition']),int(agent.variables['agent']['yPosition']))]
                for i in range(1,int(agent.modele_agent.variables['trace']['thresholdValue'])):
                    agent.modele_agent.traces.append((-100,-100))
            else:
                taille = len(agent.modele_agent.traces)
                for i in range(0,taille):
                    if DEBUG: print('  Trace. : ',i,agent.modele_agent.traces[i],'  min =',taille)
                    agent.modele_agent.traces[taille-1 - i] = agent.modele_agent.traces[taille-1 -i -1]
                agent.modele_agent.traces[0] = (agent.variables['agent']['xPosition'],agent.variables['agent']['yPosition'])
            if DEBUG: print(agent.modele_agent.traces)

    def __initField__(self):
        self.field = self.world.nbCaseY*[0] 
        for i in range(len(self.field)):
            self.field[i] = self.world.nbCaseX*[0]

    def __clearField__(self):
        for i in range(self.world.nbCaseY):
            for j in range(self.world.nbCaseX):
                self.field[i][j] = 0

    def __testeField__(self,agent):
        if type(agent.modele_agent) == Animal:
            if DEBUG: print('  Teste Field')
            self.__clearField__()
            for i in self.world.liste_agents:
                if i == agent:
                    continue
                for j in range(int(i.variables['agent']['xPosition']) - int(i.modele_agent.variables['field']['variable']),\
                               int(i.variables['agent']['xPosition']) + int(i.modele_agent.variables['field']['variable'])+1):
                    for k in range(int(i.variables['agent']['yPosition']) - int(i.modele_agent.variables['field']['variable']),\
                                   int(i.variables['agent']['yPosition']) + int(i.modele_agent.variables['field']['variable'])+1):
                        if j < 0 or k < 0 or j > self.world.nbCaseX-1 or k > self.world.nbCaseY-1:
                            continue
                        self.field[k][j] += int(i.modele_agent.variables['field']['decreaseValue'])
            if DEBUG: print('  Field=',self.field)

    def __meilleurSpot__(self,agent):
        maximum = -1000
        meilleurXY = []
        for i in range(int(agent.variables['agent']['xPosition'])-1,int(agent.variables['agent']['xPosition'])+2):
            for j in range(int(agent.variables['agent']['yPosition'])-1,int(agent.variables['agent']['yPosition'])+2):
                if i < 0 or j < 0 or i > self.world.nbCaseX-1 or j > self.world.nbCaseY-1:
                    continue
                if self.field[j][i] >= maximum:
                    maximum = self.field[j][i]
                    meilleurXY.append((i,j))
        if DEBUG: print('  Max =',maximum,' MeilleurS Spot=(',meilleurXY,')')
        a = randint(0,len(meilleurXY)-1)
        if DEBUG: print(a)
        return meilleurXY[a]
        
    def __deplaceAgent__(self, agent):
        if type(agent.modele_agent) == Animal:
            meilleurXY = self.__meilleurSpot__(agent)
            x = meilleurXY[0]
            y = meilleurXY[1]
            if x >= self.world.nbCaseX:
                x = self.world.nbCaseX-1
            if x <= 0:
                x = 0
            if y >= self.world.nbCaseY:
                y = self.world.nbCaseY-1
            if y <= 0:
                y = 0
            if DEBUG: print('  Deplacement -> x=',agent.variables['agent']['xPosition'],'->',x,' y=',agent.variables['agent']['yPosition'],'->',y)
            agent.variables['agent']['xPosition'] = x
            agent.variables['agent']['yPosition'] = y
        
    def tourSuivant(self, world):
        for i in world.liste_agents:
            if self.actif == False: # tous les agents sont morts
                if DEBUG: print('Tous les agents sont morts 2')
                break
            if DEBUG: print(world.liste_index_agents[i.type_agent],'[',i.type_agent,'] (',i.variables['agent']['xPosition'],',',i.variables['agent']['yPosition'],')')
            self.__modifieVar__(i)
            self.__testeStatus__(i)
            self.__testeField__(i)            
            #self.__testeSensor__(i)
            self.__testeNaissance__(i)
            self.__gereTrace__(i)
            self.__deplaceAgent__(i)
            if DEBUG: print('')
        if DEBUG: print('fin tour')
        if DEBUG: input('RETURN TO CONTINUE')

   
def main():
    fichier = input('entrer le nom du fichier : ')

    world = World()
    world.charge_world(fichier)
    world.init_fenetre()
    world.affiche_fenetre()
    
    jeu = Oscar(world)

    pygame.time.Clock().tick(30)
    while True and jeu.actif:
        for event in pygame.event.get():
            if event.type == pygame.QUIT or event.type == KEYDOWN:
                pygame.quit()
                sys.exit()

        jeu.tourSuivant(world)
        time.sleep(2) # pause entre deux tours
        world.affiche_fenetre()
        
    
# ------------------------------------------------------------------------------
if __name__ == '__main__':
  main()
# ==============================================================================
